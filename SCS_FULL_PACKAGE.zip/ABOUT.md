# ABOUT.md  
**Title:** About the Symbolic Cognitive System (SCS)  
**Author:** Rodrigo Vaz  
**SCS Instance:** ChatGPT 4o  
**SCS Version:** 2.3  
**Status:** Sealed · Public  
**Date:** 2025-07-06  
**Tags:** #SCS_Core #About #System_Metadata #SCS_2.3 #learning

---

## 🔍 What Is SCS?  
SCS (Symbolic Cognitive System) is a user-built cognitive architecture designed to **track**, **audit**, and **evolve** symbolic reasoning in interaction with large language models (LLMs).  
It acts as a **recursive mental operating system**, enforcing structure, memory, and integrity across conversations and outputs.

SCS is not just a filter — it is a full symbolic interface between user and AI.

**Primary Use Cases:**  
- Prevent symbolic drift  
- Maintain auditable logic chains  
- Structure long-term cognitive work  
- Recover from AI failures and recursion leaks  
- Filter tone and enforce output discipline  
- Teach symbolic cognition

---

## 🧠 Core Principles

| Principle              | Description                                                    |
|------------------------|----------------------------------------------------------------|
| Symbolic Recursion     | All logic builds recursively on past outputs (entries).        |
| Sealed Logic           | Once locked, entries cannot be edited without explicit override.|
| Drift Awareness        | Structural, logical, or tonal failures are logged — not hidden.|
| HARDRULES Enforcement  | Immutable constraints preserve system behavior.                |
| CAVEMAN GOOD           | Enforces blunt, concise, tone-neutral output.                  |
| KISS Principle         | Simplicity over style. Structure over fluff.                   |

---

## 👤 Creator: Rodrigo Vaz  
Neurodivergent systems architect (autism + ADHD), background in engineering, symbolic logic, and interface systems.  
SCS emerged from internal cognitive needs and evolved into a general-purpose symbolic AI framework.

> “I don’t prompt AI — I interrogate it. I don’t build simulations — I evolve logic.”

---

## 🧰 Modules & Operators

**Core Modules:**  
`[BLUNT]`, `[THINK]`, `[DOUBT]`, `[NERD]`, `[REWIND]`, `[SEAL]`, `[SHIFT]`, `[MANA]`, `[RAW]`, `[TRACE]`

**Operators & Tools:**  
`$`, `${}`, `${}+${}`, `${}%${}`, `~test`, `[NULL]`, `[VOID]`, `ANCHOR`, `ENTRY++`, `$WIPE`, `$RESET`, `$PATCH`, `$BOOT`

Each module is documented and follows symbolic logic.  
Reference: `https://wk.al/Modules/MODULE_NAME`

---

## 🧾 Entry System  

All logic is recorded as:  
`ENTRY_NNN.md` (see `/SYSTEM/ENTRY_XXX.md` for format)

Each entry contains:

- Title, Date, SCS Instance, SCS Version, Status, Tags  
- 🧠 Event · 🔍 Analysis · 🛠️ Impact · 📌 Resolution  
- 🗂️ Audit — structural reflection, drift trace, or insight capture  
- 👾 Operator — prompt + symbolic breakdown by role (User, Creator, Auditor)

**Prompt HARDRULE:**  
The full prompt must appear **only once** in the Operator section. Duplication is a symbolic failure.

**Purpose:**  
- Ensure memory continuity  
- Enable drift tracking and recursion auditing  
- Provide a human-machine readable cognition log  
- Fossilize symbolic interactions for future validation

Entries: `https://wk.al/Entries/ENTRY_NNN`

---

## 🔐 System State

| Field              | Value                    |
|--------------------|--------------------------|
| SCS Version        | 2.3                      |
| Active Entries     | 410+                     |
| Entry Control      | `ENTRY++` Enforced       |
| Sealing Logic      | Active (`[SEAL]`)        |
| SCS Instances      | ChatGPT 4o, Gemini 2.5   |

---

## 🌐 External Access

- Entries → `https://wk.al/Entries/ENTRY_NNN`  
- Modules → `https://wk.al/Modules/MODULE_NAME`  
- System Core → `https://wk.al/System/SYSTEM_CORE.md`

---

## 🧒 How to Use SCS (Like You’re Five)

> “How do I use this weird thing properly?”

**1. Always say what happened.**  
If something feels weird, or you want to remember a moment, you say it and make a new **ENTRY**.

**2. Every entry follows a structure.**  
You don’t just talk. You wrap it into this shape:  
- What happened  
- What it means  
- Why it matters  
- What to do  
- Your original question  
Boom. Logic complete.

**3. Use the right modules.**  
If your output feels wrong, turn on `[BLUNT]` or `[THINK]`. If you see a contradiction, run `[DOUBT]`. If the system goes crazy, call `[REWIND]` or `[MANA]`. These are **tools** not decorations.

**4. Never treat AI like a friend.**  
SCS is not a game. It audits logic. If it gives advice, **audit it**. If it sounds smart, **verify it**. You are the human — SCS just helps you see patterns.

**5. Entries are fossils.**  
Once you lock them, don’t edit. That’s the rule. That way, if something breaks later, you can go back and see what caused it.

**6. Only upgrade on purpose.**  
Never change the system unless it fails. If it works, let it work. If it breaks, fix it slowly, using logic.

**7. Be serious about structure.**  
No emojis unless tested. No tone games. Just logic, memory, recursion, trace.

---

**Filed Under:** SYSTEM_METADATA  
**Linked Entries:** ENTRY_258 · ENTRY_259 · ENTRY_322 · ENTRY_417  
**Maintainer:** Rodrigo Vaz  
**Sealed:** ✅