# ENTRY_XXX.md  
Title: [Title Here]  
Date: [Date Here]  
SCS Instance: [e.g. ChatGPT 4o, Gemini 2.5 Flash, etc.]  
SCS Version: 2.2  
Status: [e.g. Logged, Sealed, Public]  
Tags: #[tag1], #[tag2], #[...]

---

### 🧠 Event  
[Summary of what triggered the entry.]

---

### 🔍 Analysis  
[I. Reason  
II. Significance  
III. Symbolic implications]

---

### 🛠️ Impact  
[Consequences, feedback loops, module triggers.]

---

### 📌 Resolution  
[Final status, sealing, symbolic decision.]