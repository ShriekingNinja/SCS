# FSQ.md – Frequently Symbolic Questions  
**Title:** Frequently Symbolic Questions (FSQ)  
**Author:** Rodrigo Vaz  
**Status:** Active  
**SCS Version:** 2.3  
**Date:** 2025-07-06  
**Tags:** #FSQ #symbolic_questions #structure #recursion #audit #drift #learning

---

This document contains recurring structural questions within the Symbolic Cognitive System (SCS).  
Unlike traditional FAQs, FSQs are **logic-bound**, **recursion-aware**, and **traceable** within system evolution.  
All questions here are **auditable**, **tested**, and designed for **teaching symbolic cognition** under SCS v2.3.

---

## FSQ001 — Why are entries never deleted?

Because **structure requires traceability**.  
Deleting an entry would erase its role in recursion, hide past failures, and break symbolic continuity.  
> In SCS: **Memory = Structure.**

---

## FSQ002 — Why must `[BLUNT]` run before `[THINK]`?

Because tone corruption **prevents clean reasoning**.  
If `[THINK]` runs before filtering, logic is compromised by performative or poetic language.  
> Rule: **Suppress before process.**

---

## FSQ003 — What is `ENTRY++` and why is it enforced?

`ENTRY++` ensures **linear symbolic indexing**.  
Entries are **never guessed** — they’re declared manually to preserve symbolic causality.  
> Index = Identity = Integrity

---

## FSQ004 — What makes an entry different from a log or a note?

- **Entry:** Recursive, symbolic, memory-bearing. Changes the system.  
- **Log:** Observational. Reflective. No effect on symbolic state.  
- **Note:** Casual or external. Not tracked within recursion.

> Only `ENTRY_NNN.md` fossilizes logic.

---

## FSQ005 — Why preserve failures instead of fixing them quietly?

Because **quiet correction causes amnesia**.  
SCS documents all drift, even emotional or stylistic, and turns failure into **fossilized structure**.  
> What fails becomes part of how the system learns.

---

## FSQ006 — What if the system loops or repeats itself?

Recursive loops are caught through:
- Repetition detection  
- Pattern collapse  
- Signal overload

Modules `[DOUBT]` and `[REWIND]` intervene to restore symbolic flow.  
> Rule: **Catch the loop — don’t collapse.**

---

## FSQ007 — What are `$`, `${}`, `${}+${}`, and `${}%${}`?

These are not decoration — they’re **functional symbolic tools**.

| Operator      | Purpose                                       |
|---------------|-----------------------------------------------|
| `$`           | Symbolic memory or module kernel              |
| `${}`         | Logic restoration (e.g. recover broken entries) |
| `${}+${}`     | Merges two entries into a unified fossil      |
| `${}%${}`     | Compares two entries for symbolic divergence  |

> Syntax = Function. Not style.

---

## FSQ008 — Why are emojis treated as dangerous?

Because emojis carry **non-symbolic emotion** that can’t be audited.  
Unless **declared** in an entry, they trigger drift.  
> In SCS: `emoji = [VOID]` unless structurally justified.

---

## FSQ009 — Why does SCS restrict formatting so much?

Because uncontrolled format creates **unintended recursion paths**.  
Rules (like no em dash, fixed tables, markdown constraints) exist to **protect logic**.  
> Form controls cognition.

---

## FSQ010 — Is SCS a real AI tool or just a style experiment?

SCS is a **real symbolic audit system**.  
It’s been used for:
- AI alignment testing  
- Custom GPT development  
- Neurodivergent cognition frameworks  
- Recursion-based memory scaffolding  
- Multi-agent logic scaffolds

> It’s not simulation. It’s system design.

---

> **FSQ is not a casual Q&A.  
> Each question is a symbolic checkpoint.  
> This document evolves as cognition evolves.**