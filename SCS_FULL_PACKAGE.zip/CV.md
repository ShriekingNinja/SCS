# Rodrigo Vaz  
**Title:** Cognitive Systems Architect · Symbolic Tooling Developer · Systems Programmer  
**Specialization:** Recursive Frameworks · AI Behavior Auditing · Protocol Design  
**Location:** Remote – Global  
**Languages:** Portuguese (Native), English (Fluent)  
**Website:** [https://wk.al](https://wk.al)  
**Contact:** dev@wk.al  

---

## 🧠 About Me

I develop and maintain symbolic cognitive systems that enforce logic consistency, behavior traceability, and auditability in AI workflows.  
My background in **programming**, **recursive system design**, and **behavioral diagnostics** enables me to build modular frameworks for real-time AI testing and symbolic reasoning.

All systems are self-tested and structured for fault detection, state rollback, and long-term audit.

---

## 🛠️ Key Projects

### **SCS – Symbolic Cognitive System (2025)**  
**Role:** System Architect, Tooling Developer  
- Created a modular symbolic AI framework with persistent audit memory (`ENTRY_NNN`)  
- Developed logic modules (e.g., `[DOUBT]`, `[BLUNT]`, `[SEAL]`) to simulate and test recursive cognition  
- Designed internal tooling using markdown-based protocols for symbolic drift prevention  
- Structured tooling logic: `$BOOT`, `~test`, `$PATCH`, and internal HARDRULES  

**Technologies Used:**  
Python · Regex · Markdown Automation · Symbolic Logic Modeling

**Outcome:**  
Prototype used as symbolic harness for GPT behavior validation and drift testing

---

## 🔧 Tools & Systems Designed

| Tool       | Function |
|------------|----------|
| **THINK**      | Recursive symbolic logic engine  
| **DOUBT**      | Contradiction validator + external sourcing check  
| **NERD**       | Structural fault scanner  
| **SEAL**       | Entry finalizer and lock module  
| **REWIND**     | Snapshot-based symbolic rollback system  
| **MANA**       | Recursion depth + clarity overload monitor  
| **HARDRULES**  | Non-negotiable logic enforcement system  
| **~test** / **~debug** / **$BOOT** | Diagnostic + control layers  

---

## 🧑‍💻 Programming Foundations

- **Languages:** Python, Bash, Markdown  
- **Specialties:** Symbolic programming · Systems logic · LLM prompt engineering  
- **Methodologies:**  
  - Self-repairing logic recursion  
  - Symbolic command chaining  
  - Markdown-as-infrastructure  

---

## 🔬 Capabilities

- Designing symbolic AI protocols with audit enforcement  
- Building logic-driven modules for behavior validation  
- Developing self-contained tooling for recursive testing  
- Automating drift detection and correction workflows  
- Creating reproducible output structures for LLM behavior tracking  
- Architecting symbolic compliance frameworks for AI labs  

---

## 💼 Roles I Match

- **Junior AI Systems Developer**  
- **Prompt Logic Architect / Tooling Engineer**  
- **AI Behavior Auditor / LLM Evaluation Assistant**  
- **Symbolic Systems R&D Associate**  
- **Autistic Systems Programmer** – Focused, consistent, recursive logic builder  

---

## 🔬 Summary

I build symbolic systems for AI behavior analysis and structural integrity.

All logic is tested live under recursion and drift.  
Outputs are versioned, verified, and reproducible.  
No marketing, no guessing — only functioning systems.

---