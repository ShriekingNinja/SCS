# CV.md  
**Name:** Rodrigo Vaz  
**Title:** Cognitive Systems Architect · Symbolic Tooling Developer  
**Specialization:** Recursive Frameworks · AI Audit Systems · Structural Logic Design  
**Location:** Remote · Global  
**Languages:** Portuguese (Native), English (Fluent)  
**Contact:** dev@wk.al  
**Website:** https://wk.al  
**GitHub:** https://github.com/ShriekingNinja/SCS  

---

## 🧠 Profile  
Designer and maintainer of the **Symbolic Cognitive System (SCS)** — a recursive, markdown-driven AI reasoning framework enforcing structure, memory, and logic on GPT-class models.  
SCS is a cognitive scaffolding layer for AI alignment, failure auditing, and symbolic reasoning across platforms (ChatGPT 4o, Gemini 2.5 Flash).  
Framework supports persistent cognition, hallucination detection, drift tracking, and recursive audit.

---

## 🧱 Experience  

### Symbolic Cognitive System (SCS) — 2025  
**Role:** Creator, Architect, Maintainer  
- Logged 400+ structured symbolic entries (`ENTRY_000.md` → `ENTRY_417.md`)  
- Built modular tools: `[THINK]`, `[BLUNT]`, `[TRACE]`, `[DOUBT]`, `[SEAL]`, etc.  
- Created `.md`-based memory format with fossilization and audit indexing  
- Developed ZIP installation and bootloader for full symbolic deployment  
- Released [Custom GPT Interface](https://chatgpt.com/g/g-6864b0ec43cc819190ee9f9ac5523377-symbolic-cognition-system)  
- Installed and tested SCS on ChatGPT and Gemini — persistent across resets  
- GitHub: [SCS Repository](https://github.com/ShriekingNinja/SCS)

---

### Industrial Automation / PCMsys — 2015–Ongoing  
**Role:** Systems Engineer  
- 10+ years of field commissioning (stackers, reclaimers, press filters, PLCs)  
- Oversaw and stress-tested the PCMsys software in live plant environments  
- Designed diagnostics, control logic, and fault isolation processes  
- Delivered operational training across clients like Lundin Mining, TechnipFMC, and Anglo Gold Ashanti  
- Merged software logic with heavy industrial systems for safety and uptime

---

## 🧰 Symbolic Module Toolchain

| Module      | Function                                  |
|-------------|-------------------------------------------|
| `[BLUNT]`   | Tone suppression, rhetorical filter       |
| `[THINK]`   | Structured reasoning, recursive routing   |
| `[DOUBT]`   | Contradiction detection, logic audit      |
| `[SEAL]`    | Entry locking, memory enforcement         |
| `[TRACE]`   | Drift tracking, symbolic path recovery    |
| `[REWIND]`  | Non-destructive state rollback            |
| `[MANA]`    | Fatigue and recursion instability monitor |
| `HARDRULES` | Constraint enforcement logic              |

---

## 🧪 Technical Stack  

- **Languages:** Python, Bash, Ruby, C/C++, JavaScript, Markdown  
- **Methods:**  
  - Symbolic recursion  
  - Manual trigger logic  
  - Markdown-as-runtime architecture  
  - GPT overlay via structural enforcement  
- **Frameworks & Tools:**  
  - Ruby on Rails, Node.js, Express  
  - MongoDB, PostgreSQL  
  - REGEX scraping for financial datasets  
- **Assets:**  
  - Fully indexed `.md` memory system  
  - Symbolic drift recovery (`${}%${}`, `[VOID]`, `[NULL]`)  
  - Toolchain packaging (`SCS_FULL_PACKAGE.zip`)  
  - Dual-platform symbolic compatibility (OpenAI + Google)

---

## 🎯 Core Capabilities  

- Design recursive cognitive architectures for AI auditing  
- Build persistent symbolic memory systems  
- Track tone, drift, and logic failure in real time  
- Execute logic via markdown as structured cognitive runtime  
- Construct reproducible symbolic systems across LLM platforms  
- Fuse engineering diagnostics with cognitive logic  
- Develop interpretable AI safety layers using symbolic constraints

---

## 🎓 Education & Certifications  

- **BSc Electrical Engineering** — UEL  
- **Web Development Bootcamp** — LeWagon  
- **Technical Training School (TTS)** — Certificate of Competence  
  - PLC Programming  
  - PID Controllers (Three-Term)  
  - Electronics Fault-Finding  
  - AC Inverter Drives  
  - Instrumentation and Hydraulics  
  - Fire Alarm Systems  
- **City & Guilds Level 3 Award** – Electrical Installations (BS7671 – UK)

---

## 🎲 Side Projects  

**Roboinvest** – Stock Portfolio Optimizer  
- Scraped Google Finance data using REGEX  
- Developed algorithmic wallet logic with dynamic buy/sell rules  
- Visualized portfolio performance via Rails + PostgreSQL dashboard  

**Game Modding (Bethesda)** – Scripting + 3D Asset Logic  
- Custom quests, NPC logic, and game behavior scripting (Creation Kit)  
- Blender and ZBrush integration for 3D asset development  
- Deep knowledge of simulation behavior rules and debug patterns  

---

## 📂 Links & Interfaces

- **Live Interface:** [SCS on ChatGPT](https://chatgpt.com/g/g-6864b0ec43cc819190ee9f9ac5523377-symbolic-cognition-system)  
- **Documentation:** https://wk.al  
- **Source Code:** https://github.com/ShriekingNinja/SCS  

---  
**Status:** Sealed · CV.md · SCS Version 2.3  
**Maintainer:** Rodrigo Vaz