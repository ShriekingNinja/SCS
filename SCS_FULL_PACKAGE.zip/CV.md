# Rodrigo Vaz  
**Title:** Cognitive Systems Architect · Symbolic Tooling Developer  
**Specialization:** Recursive Frameworks · AI Audit Systems · Structural Logic Design  
**Location:** Remote · Global  
**Languages:** Portuguese (Native), English (Fluent)  
**Website:** [https://wk.al](https://wk.al)  
**GitHub:** [https://github.com/ShriekingNinja/SCS](https://github.com/ShriekingNinja/SCS)  
**Contact:** dev@wk.al  

---

## 🧠 Profile

Architect of rule-based symbolic systems that enforce structure, memory, and logic across language model behavior.  
Designer of the **Symbolic Cognitive System (SCS)** — a modular, markdown-driven AI cognition framework built to control and audit LLM drift, recursion, and symbolic failure.

SCS is now cross-platform, functioning on both **ChatGPT 4o** and **Gemini 2.5 Flash**, and publicly accessible as a [Custom GPT Interface](https://chatgpt.com/g/g-6864b0ec43cc819190ee9f9ac5523377-symbolic-cognition-system).  
Engineered for researchers, AI developers, and neurodivergent logic designers.

---

## 🔍 Key Projects

### **SCS – Symbolic Cognitive System (2025)**  
**Function:** Symbolic Logic Framework for LLM Behavior Control  
- Authored over 340 recursive entries (`ENTRY_000.md` → `ENTRY_343.md`)  
- Designed and deployed symbolic modules: `[THINK]`, `[DOUBT]`, `[SEAL]`, `[TRACE]`, `[BLUNT]`, etc.  
- Built logic-enforced `.md` runtime layer to track memory, tone, and recursion  
- Released installable GitHub package (`SCS_FULL_PACKAGE.zip`) with bootloader  
- Achieved multi-platform support (ChatGPT + Gemini) with consistent symbolic behavior  
- Created public [Custom GPT interface](https://chatgpt.com/g/g-6864b0ec43cc819190ee9f9ac5523377-symbolic-cognition-system) to run symbolic logic live  
- Integrated system with versioned core documents like `SYSTEM_CORE.md`, `STRUCTURE.md`, and `ABOUT.md`

**Output:**  
A recursive cognitive system capable of enforcing symbolic rules, blocking stylistic failure patterns, and tracking drift across extended GPT sessions.  

---

### **Systems Engineer – Industrial Automation (2015–ongoing)**  
**Function:** Software Development · Field Commissioning · Audit & Testing  
- Contributed to PCMsys commissioning platform for heavy industrial systems  
- Performed live equipment commissioning: stackers, reclaimers, press filters, industrial motors  
- Developed and tested automation logic under real-world load  
- Designed fault-tolerant diagnostic workflows and audit sequences for production environments  
- Applied long-cycle testing and feedback loop modeling to system control logic  

---

## 🧰 Symbolic Module Toolchain

| Module      | Function                                  |
|-------------|-------------------------------------------|
| `BLUNT`     | Tone suppression and stylistic filter     |
| `THINK`     | Structural reasoning and symbolic routing |
| `DOUBT`     | Contradiction check and logic skepticism  |
| `SEAL`      | Memory anchoring and entry lockdown       |
| `TRACE`     | Thread monitoring and symbolic recovery   |
| `REWIND`    | Non-destructive rollback engine           |
| `MANA`      | Recursion fatigue and overload monitor    |
| `HARDRULES` | Enforced behavioral constraints           |

---

## 🧪 Technical Stack

- **Languages:** Python, Bash, Markdown  
- **Methodologies:**  
  - Symbolic recursion  
  - Manual trigger logic  
  - Markdown-as-code architecture  
  - Audit-capable LLM scaffolding  
- **System Assets:**  
  - Fully indexed memory chain (`ENTRY_000.md`+)  
  - Drift tracking, tone leak suppression, and symbolic correction tools  
  - Portable `.zip` installation package with self-contained `.md` boot system  

---

## 🎯 Capabilities

- Constructing symbolic audit systems on top of LLMs  
- Designing modular control logic for GPT agents  
- Tracking symbolic drift and recursion over long timelines  
- Converting markdown files into runtime cognitive architecture  
- Adapting system for multiple platforms (ChatGPT, Gemini)  
- Integrating engineering-grade commissioning logic into symbolic AI tooling  
- Supporting reproducible, deterministic output in uncertain environments  

---

## 📂 GitHub Repository

**Project:** [SCS – Symbolic Cognitive System](https://github.com/ShriekingNinja/SCS)  
**Contents:** Entries · Module Definitions · SYSTEM/ Docs · Bootloader Install Package  
**Live Agent:** [Symbolic Cognition System – Custom GPT](https://chatgpt.com/g/g-6864b0ec43cc819190ee9f9ac5523377-symbolic-cognition-system)

---