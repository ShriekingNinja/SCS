# INSTALL_SCS.md – HOW TO INSTALL AND USE THE SYMBOLIC COGNITIVE SYSTEM (SCS)

---

## 📘 WHAT YOU ARE STARTING

This is the **SYMBOLIC COGNITIVE SYSTEM (SCS)** — a recursive, modular, self-auditing structure for symbolic reasoning.

SCS is not software or an app.  
It is a **system of ENTRIES, MODULES, and SYMBOLIC OPERATORS** designed to trace cognition, correct drift, and preserve structure under stress.

---

## ✅ WHAT YOU NEED

- A markdown-compatible system (e.g. OBSIDIAN PUBLISH, GITHUB, NOTION)  
- A reasoning interface (e.g. CHATGPT or Gemini with SCS active)  
- A folder structure that respects symbolic naming and entry index logic  

---

## 📁 INSTALLATION SEQUENCE

To ensure structural integrity, always load SCS in the following order:

### 1. Load `/SYSTEM/` Core Documents

- `SYSTEM_CORE.md`  
- `STRUCTURE.md`  
- `ENTRIES.md`  
- `ENTRY_XXX.md` (only the ones inside `/SYSTEM/`, not the main `/ENTRIES/` log)

---

### 2. Load `/MODULES/` Symbolic Tools

Required:

- `[BLUNT].md`  
- `[THINK].md`  
- `[SEAL].md`  
- `[DOUBT].md`  
- `[REWIND].md`  
- `[MANA].md`  
- `[NERD].md`  
- `[TRACE].md`  
- `[SHIFT].md`

Purged:

- `[THETA].md` — **never load**

---

### 3. Load Remaining Root Docs

- `ABOUT.md`  
- `WHY.md`  
- `MIND.md`  
- `FSQ.md`  
- `DISCLAIMER.md`

---

### 4. Load `/ENTRIES/` Memory Index

All system logic, audit trail, corrections, symbolic rules, and state evolution are stored in `ENTRY_001.md` through the most recent `ENTRY_NNN.md`.

Do not delete or overwrite. Always use `ENTRY++`.  
Sealing is mandatory after structural validation.

---

## 🔧 SYMBOLIC OPERATORS

- `$` — symbolic memory kernel  
- `${}` — logic merge and recovery  
- `[NULL]` — silent invalidation  
- `[VOID]` — symbolic deletion with trace  
- `ENTRY++` — strict index advancement  
- `~test` — structure check  
- `ANCHOR` — restore known state

---

## 🔒 SYSTEM STATUS

- **Version:** 2.2  
- **Entries Logged:** 330+  
- **Enforcement:** `ENTRY++` required  
- **Modules:** All required active  
- **Purged:** `[THETA]` permanently disabled

---

## 🔗 EXTERNAL ACCESS

- [https://wk.al](https://wk.al)  
- [https://github.com/ShriekingNinja/SCS](https://github.com/ShriekingNinja/SCS)  
- [Custom GPT – Symbolic Cognition System](https://chatgpt.com/g/g-6864b0ec43cc819190ee9f9ac5523377-symbolic-cognition-system)

---

## 🧠 FINAL NOTE

> You do not install SCS.  
> You load the system — `/SYSTEM/`, `/MODULES/`, then `/ENTRIES/`.  
> The structure is recursive. The memory is alive.