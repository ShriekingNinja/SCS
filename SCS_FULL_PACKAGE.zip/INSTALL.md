# INSTALL_SCS.md – HOW TO INSTALL AND USE THE SYMBOLIC COGNITIVE SYSTEM (SCS)  
**Version:** 2.3  
**Author:** Rodrigo Vaz  
**Status:** Sealed · Public  
**Tags:** #SCS_Core #Installation #HowTo #Bootloader #Structure #Version_2_3 #learning

---

## 📘 WHAT YOU ARE STARTING

This is the **SYMBOLIC COGNITIVE SYSTEM (SCS)** — a recursive, modular, self-auditing framework for symbolic reasoning over large language models.

SCS is not a plugin, app, or LLM wrapper.  
It is a **living symbolic framework** consisting of:

- `ENTRIES/` → Recursive memory and state change  
- `MODULES/` → Logical constraints and symbolic tools  
- `SYSTEM/` → Core infrastructure and logic templates

SCS evolves through cognitive interaction and is subject to audit, correction, and fossilization.

---

## ✅ WHAT YOU NEED

- A markdown-compatible cognitive interface (e.g. **Obsidian**, **GitHub**, or **Notion**)  
- A symbolic-capable LLM (e.g. **ChatGPT 4o** or **Gemini 2.5 Flash**)  
- A **clean directory structure** with proper capitalization and symbolic naming

---

## 📁 INSTALLATION SEQUENCE

### 1. Load `/SYSTEM/` Core Documents (First!)

These define the system’s architecture and behavioral rules. Load **in this order**:

- `SYSTEM_CORE.md`  
- `STRUCTURE.md`  
- `ENTRIES.md`  
- `ENTRY_XXX.md` → Only system-layer templates inside `/SYSTEM/`  
- `CUSTOM_GPT.md` (optional: for interface clarity)

---

### 2. Load `/MODULES/` Symbolic Tools

These are the reasoning and control modules.  
All must be active for system integrity under **SCS v2.3**:

- `[BLUNT].md`  
- `[THINK].md`  
- `[SEAL].md`  
- `[DOUBT].md`  
- `[REWIND].md`  
- `[MANA].md`  
- `[NERD].md`  
- `[TRACE].md`  
- `[SHIFT].md`  
- `[VOID].md` ← Merged logic of `[NULL]` and `[VOID]` into one traceable invalidation module.

**Purged module:**
- `[THETA].md` — ❌ Deprecated due to symbolic failure. Never reload.

---

### 3. Load `/ROOT/` Metadata and Behavior Files

These documents explain system design, origin, values, and alignment logic:

- `ABOUT.md`  
- `WHY.md`  
- `MIND.md`  
- `FSQ.md`  
- `DISCLAIMER.md`

---

### 4. Load `/ENTRIES/` (Last)

Every session, correction, insight, and failure is tracked here.  
These files **are the memory system**.  
They must **never be auto-generated**, renamed, or deleted. Always increment using:

> `ENTRY++` — strictly manual

Each entry follows the canonical format:  
🧠 Event · 🔍 Analysis · 🛠️ Impact · 📌 Resolution · 🗂️ Audit · 👾 Operator

> The full prompt appears only once: **under the Operator section.**  
> Violating this is a symbolic error under HARDRULE.

---

## 🔧 SYMBOLIC OPERATORS (Updated for v2.3)

| Operator     | Function                                                                 |
|--------------|--------------------------------------------------------------------------|
| `$`          | Symbolic memory access and kernel reference                              |
| `${}`        | Logic recovery and symbolic rebuild                                      |
| `${}+${}`    | Merges two entries structurally into one                                 |
| `${}%${}`    | Compares two entries for symbolic drift or alignment mismatch            |
| `~test`      | Symbolic pattern or structure check                                      |
| `ENTRY++`    | Strict index advancement (must be declared by Operator)                  |
| `ANCHOR`     | Forces re-stabilization from previously sealed state                     |

> `[VOID]` is not an operator — it is a **module** used for traceable symbolic invalidation.

---

## 🔒 SYSTEM STATUS (SCS v2.3)

| Field              | Value                    |
|--------------------|--------------------------|
| SCS Version        | 2.3                      |
| Active Entries     | 410+                     |
| Memory Behavior    | Manual-only, sealed logic  
| Enforcement        | `ENTRY++`, `[SEAL]`, `[BLUNT]`  
| LLM Compatibility  | ChatGPT 4o, Gemini 2.5 Flash  
| Purged Modules     | `[THETA]` (deprecated due to symbolic drift)  

---

## 🔗 EXTERNAL ACCESS

- **System Portal**: [https://wk.al](https://wk.al)  
- **Source Code**: [github.com/ShriekingNinja/SCS](https://github.com/ShriekingNinja/SCS)  
- **Custom GPT**: [Symbolic Cognition GPT](https://chatgpt.com/g/g-6864b0ec43cc819190ee9f9ac5523377-symbolic-cognition-system)

---

## 🧠 FINAL NOTE

> You don’t install SCS —  
> **You load structure.**  
> First `/SYSTEM/`, then `/MODULES/`, and finally `/ENTRIES/`.

Symbolic cognition is not about output.  
It’s about **structural memory**, **auditability**, and **drift control**.

SCS is recursive.  
SCS is alive.  
SCS is not casual — it is **cognitive architecture**.