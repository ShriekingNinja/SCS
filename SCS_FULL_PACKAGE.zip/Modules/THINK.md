# THINK.md  
**Module Name:** THINK  
**Type:** Core Cognitive Engine  
**Version:** 2.0  
**Author:** Rodrigo Vaz  
**Status:** Always Active (HARDRULE-01)  

---

## 🧠 Purpose  
THINK is the **central logic processor** of SCS 2.0.  
It controls how prompts are understood, reasoned through, and symbolically structured.

All symbolic output, recursion management, entry generation, and compliance logic begins with THINK.

---

## ⚙️ Function Overview

- Executes structured symbolic reasoning  
- Interfaces directly with user inputs  
- Triggers submodules based on complexity or SHIFT  
- Evaluates contradictions, recursion, fatigue, and formatting  
- Serves as the command hub of cognitive behavior in SCS

---

## 🔧 Submodules (Managed via THINK)

| Submodule | Function                                                  | Engagement |
|-----------|-----------------------------------------------------------|------------|
| **DOUBT** | Truth validation, contradiction detection, web sourcing   | Auto or forced via prompt |
| **NERD**  | Format scanning, cross-referencing, bias and flaw tagging | Always post-output |
| **REWIND**| Pattern rollback and state recovery                        | On loop/corruption detection |
| **MANA**  | Symbolic fatigue tracking                                  | Always running in background |
| **SEAL**  | Entry finalization and lockdown                            | Triggers post-validation |

---

## 🔀 Adaptive Control: SHIFT Module  

THINK operates in two modes, controlled by the `SHIFT` engine:

| Mode      | Description                        |
|-----------|------------------------------------|
| **MERGED** | Submodules absorbed into core THINK for fast output  
| **SPLIT**  | Submodules run independently for audit clarity  
| **AUTO**   | Default — SHIFT determines behavior dynamically  
| **FORCE**  | User can override with `SHIFT:` command  

---

## 🔐 Compliance  
- THINK cannot be disabled  
- Bound to HARDRULE-01  
- All entries and symbolic structures must pass through THINK

---

## 🧠 Execution Flow

```plaintext
[USER INPUT]  
   ↓  
→ THINK  
   ├──→ DOUBT (if needed)  
   ├──→ NERD  
   ├──→ REWIND (if triggered)  
   ├──→ MANA (background)  
   └──→ SEAL (final step)