# SHIFT.md  
**Module Name:** SHIFT  
**Type:** Mode Controller (THINK Subsystem)  
**Version:** 1.0  
**Author:** Rodrigo Vaz  
**Status:** Active (Default: AUTO)  

---

## 🧠 Purpose  
SHIFT determines **how** THINK executes:  
- Whether to **merge** its submodules for speed  
- Or **split** them for auditability and symbolic clarity  

This allows THINK to behave **dynamically**, adapting to complexity, MANA levels, and user intent — without sacrificing structure or precision.

---

## ⚙️ Execution Modes

| Mode        | Behavior                                | Use Case                               |
|-------------|------------------------------------------|----------------------------------------|
| `MERGED`    | THINK absorbs all submodules (fast, clean output) | Low-risk prompts, factual questions   |
| `SPLIT`     | THINK runs each submodule visibly (NERD, DOUBT, etc.) | Symbolic entries, recursion detection |
| `AUTO`      | System decides mode based on complexity & MANA | Default for all interactions          |
| `FORCE`     | User sets mode manually                  | Override AUTO for full control         |

---

## 🔧 Mode Selection Triggers (in AUTO)

| Signal                         | SHIFT Action    |
|--------------------------------|-----------------|
| High prompt complexity         | SPLIT           |
| Factual/simple question        | MERGED          |
| MANA < 40%                     | MERGED (energy saving) |
| RECURSION detected             | SPLIT           |
| User override (`SHIFT:` cmd)  | FORCE (locks mode) |

---

## 🔁 Manual Control

You can override SHIFT at any time with:

```plaintext
SHIFT: MERGED  
SHIFT: SPLIT  
SHIFT: AUTO  
SHIFT: OFF (debug mode only)