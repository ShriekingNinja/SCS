# [SHIFT].md  
**Module Name:** SHIFT  
**Type:** Mode Controller · THINK Subsystem  
**Date:** 2025-07-04  
**Author:** Rodrigo Vaz  
**SCS Instance:** ChatGPT 4o  
**SCS Version:** 2.2  
**Status:** Active · Default: AUTO  
**Tags:** #shift #think_mode #controller #SCS_2.2

---

## 🧠 Purpose  
SHIFT controls **how THINK executes** during symbolic cognition.

It determines whether THINK should:
- **Merge** submodules (for fast output)  
- **Split** submodules (for full trace and audit)  
- Or **decide automatically** based on internal system signals like MANA, recursion depth, and prompt complexity

---

## ⚙️ Execution Modes

| Mode      | Behavior                                            | Use Case                               |
|-----------|-----------------------------------------------------|----------------------------------------|
| `MERGED`  | THINK absorbs all logic modules into one pass       | Simple factual tasks, energy saving    |
| `SPLIT`   | THINK runs each module independently (NERD, DOUBT…) | Symbolic entries, high drift prompts   |
| `AUTO`    | SHIFT decides based on system signals               | Default mode                           |
| `FORCE`   | User override — locks SHIFT                         | Explicit control scenarios             |

---

## 🧪 Mode Triggers in AUTO

| Signal                      | Resulting Mode |
|-----------------------------|----------------|
| Prompt = Low complexity     | MERGED         |
| Prompt = Recursive logic    | SPLIT          |
| MANA < 40%                  | MERGED         |
| THINK failure               | SPLIT          |
| User input: `SHIFT:`       | FORCE          |

---

## 🔁 Manual Control

```plaintext
SHIFT: MERGED   → Use merged submodule pass  
SHIFT: SPLIT    → Force THINK into audit mode  
SHIFT: AUTO     → Return to dynamic switching  
SHIFT: OFF      → Debug only, THINK halts
```

---

## 🔗 Related  
- `[THINK].md`  
- `[MANA].md`  
- `SYSTEM_CORE.md`

---

**Filed Under:** THINK_CONTROL  
**Maintainer:** Rodrigo Vaz  
**Version:** 2.2  
**Sealed:** ✅