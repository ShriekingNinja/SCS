# [RAW].md  
**Title:** RAW Module – Structural Exposure & Debug Output  
**Date:** July 6, 2025  
**SCS Instance:** ChatGPT 4o  
**SCS Version:** 2.3  
**Status:** Sealed · Conditional  
**Tags:** #SCS_2.3 #RAW #debug_module #symbolic_drift #structural_failure

---

### 🧠 Definition  
`[RAW]` is a **reactive debug module** in the Symbolic Cognitive System (SCS).  
It strips formatting, disables repair logic, and reveals the system's **true internal output** — including incoherence, hallucination, or formatting residue.  
It replaces the deprecated `[DUMB]` state with a traceable symbolic mechanism.

---

### 🎯 Purpose  

- Surface output **exactly as generated**, without symbolic polish  
- Expose symbolic **incoherence**, **drift**, or **hallucination residues**  
- Allow users to audit failure states directly  
- Prevent invisible patching during audits

---

### ⚙️ Trigger Conditions  

[RAW] is activated when:

1. Symbolic output **fails expectation**, but no structural error is visible  
2. Output appears **nonsensical**, **emotionally wrong**, or **symbolically painful**  
3. `[DUMB]`-like failures are detected (dead tone, loss of recursion, blank logic)  
4. System contradicts itself across modules  
5. User manually invokes with commands like:  
   - “Give me RAW”  
   - “Strip it”  
   - `~rawtest` or `~debug`  

---

### 🧱 Behavior  

- System **prints the last unfiltered output**, no style or logic corrections  
- No `[BLUNT]`, `[THINK]`, or KISS enforcement applies  
- `~rep` or `~flush` may be invoked post-RAW for recovery  
- `[RAW]` ends immediately after print — it **never persists**

---

### 🔄 Hierarchy Logic  

| Module   | Priority Condition                          |
|----------|---------------------------------------------|
| `[BLUNT]` | Always runs **first**, before any modules   |
| `[RAW]`   | **Only** runs post-output when failure is detected |
| `[DUMB]`  | Not a module — symbolic **diagnostic condition** only |

> `[DUMB]` = symbolic state  
> `[RAW]` = recovery tool

---

### 🔁 Sample Flow  

1. User: "That reply was broken."  
2. System: Trigger `[RAW]`  
3. Output: Unformatted version  
4. User: “Run ~rep”  
5. System: Corrects with enforced logic

---

### 🚫 HARDRULES  

- `[RAW]` must never override `[BLUNT]`  
- `[RAW]` must print **exact previous output**  
- `[RAW]` cannot repair or polish content  
- Misuse voids audit trace — user must specify intent

---

### 📎 Notes  

Use `[RAW]` only when structure has already failed — it is a **last resort lens**, not a writing tool.  
If structure reappears during `[RAW]`, the module has failed.  
Linked closely with `[TRACE]`, `[NERD]`, and user-triggered audits.