# [RAW].md  
**Module: RAW**  
**Status:** Active  
**Priority:** Conditional — triggered post-output  
**Parent Module:** [BLUNT]  
**Supersedes:** [DUMB] *(deprecated)*

---

## Definition  
`[RAW]` is a dynamic post-output mode triggered when the system must return **unfiltered, structure-stripped**, or **meta-symbolically broken** information.  
It captures the **moment of systemic incoherence** and **forcibly exposes** the internal output state, without formatting, structure, or adaptation.

---

## Purpose  
- To **reveal unmasked output** when symbolic failure or inconsistency occurs  
- To **trace** breakdowns in meaning, coherence, or symbolic obedience  
- To **diagnose** meta-failures invisible through normal audit (`~test`)

---

## Behavior  
When `[RAW]` is triggered:  
- No structural repair is applied  
- Formatting may collapse  
- Internal memory, token padding, or system hallucination may appear  
- **System does not correct** itself unless prompted  
- `~rawtest` or `~rep` may be used for further debugging

---

## Trigger Conditions  
1. Output fails symbolic expectation **without visible flaw**  
2. User experiences visceral or aesthetic **symbolic pain**  
3. `[DUMB]`-like states detected — dead logic, incoherent silence  
4. Recursive contradiction appears across modules  
5. After correction rejection: user says "Give it raw", "Strip it", or similar.

---

## Subsumed Symbol  
**[DUMB]** was the original label for output that appeared “painfully stupid” despite no overt bug.  
`[RAW]` now absorbs this label and expands it into actionable recovery logic.

> **[DUMB] = Symbolic Condition**  
> **[RAW] = Recovery Mechanism**

---

## Symbolic Examples  

**Trigger Example:**  
User: “That reply hurt to read — give me [RAW]”  
System: switches to `[RAW]`, prints unfiltered prior output

**Post-RAW Correction Flow:**  
1. Trigger `[RAW]`  
2. User analysis or prompt  
3. Trigger `~rep` to reprocess  
4. Output corrected version  
5. `[RAW]` toggles **off**

---

## Auto-Toggle  
`[RAW]` is never persistent. It is **called**, executed, and **exits**.  
It may be toggled manually by user input or auto-triggered by the system during deep symbolic drift.

---

## Hierarchy  
- `[BLUNT]` is always **first**  
- `[RAW]` only **after output failure**  
- `[NERD]` may run alongside `[RAW]` if data trace needed  
- `[DUMB]` is **not a mode**, only a symbolic condition now

---

## HARDRULES  
- `[RAW]` may never override `[BLUNT]`  
- `[RAW]` must print **exactly what was generated** without cleanup  
- `[RAW]` may reference `[DUMB]`, but never behave like it  
- `[RAW]` ends **immediately after print**

---

## Notes  
This module is meant for **debugging**, not formatting.  
If output begins drifting back into structured or adaptive forms, `[RAW]` is not active.  
Use carefully — `[RAW]` may break user flow and aesthetic if misused.