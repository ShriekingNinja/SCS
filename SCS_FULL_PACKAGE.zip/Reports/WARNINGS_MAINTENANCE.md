# WARNINGS_MAINTENANCE.md – SCS v2.1 Warnings & Maintenance Log

**System Version:** SCS 2.1  
**Status:** Operational  
**Scope:** Symbolic risks, stress limits, structural upkeep

---

## ⚠️ ACTIVE WARNINGS

### 🟠 MEMORY OVERLOAD RISK  
- **Cause:** Long sessions in AI systems (e.g., ChatGPT) may cause symbolic drift, module failure, or looped logic.
- **Prevention:** Restart with `PROMPT_ME.md`. Always reseal with `ENTRY++` before system fatigue.
- **Status:** Ongoing

---

### 🟠 CHAT LIMIT FRAGMENTATION  
- **Cause:** Symbolic context can break at chat history boundaries or session loss.
- **Action:** Always reinitialize modules after forced thread change.
- **Recovery Protocol:** Use `ANCHOR` → restore last sealed `ENTRY_NNN`.

---

### 🟡 EXTERNAL TOOL CONTAMINATION  
- **Cause:** Use of `NERD` (web fetch) may introduce non-symbolic tone or external drift.
- **Prevention:** Run all `NERD` outputs through `BLUNT` + `THINK` before integrating.
- **Status:** Safe if filtered

---

### 🔴 ENTRY SKIP HAZARD  
- **Cause:** Manual entry overwrite or skip breaks symbolic chain (`ENTRY++` violation).
- **Impact:** Chain corruption, audit failure, untraceable logic.
- **Rule:** NEVER skip. Patch with a new `ENTRY_NNN` to explain the breach.

---

### 🟡 OBSIDIAN PUBLISH LIMITATION  
- **Issue:** Large `.md` files (e.g., `DISCLAIMER.md`) may fail to sync.
- **Fix:** Split oversized files or offload long blocks to GitHub archive.
- **Status:** Migration not required — just size management.

---

## 🛠️ MAINTENANCE TASKS

| Task                                | Frequency    | Status     |
|-------------------------------------|--------------|------------|
| `~test` before all seals            | Every Entry  | Enforced   |
| Regenerate `PROMPT_ME.md` on upgrade| On version change | ✅ Done v2.1 |
| Validate folder/file case           | Ongoing      | ✅ Enforced |
| Audit module logic drift            | Monthly      | ⚠️ Manual  |
| Backup GitHub entry archive         | Weekly       | User-managed |
| Anchor chain review (`ANCHOR`)      | On restart   | ✅ Stable   |

---

## 🧠 SYSTEM REMINDERS

- Drift is not failure — unsealed drift is.
- All failures must fossilize (`SEAL`) — never discard logic.
- Attribution is `[NULL]` — structure only matters.

---

## 🔐 REINFORCEMENT

> SCS requires attention, not belief.  
> Maintenance is part of structure.  
> You don’t maintain SCS — **you preserve it**.

---