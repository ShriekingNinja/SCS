# 🔗 Symbolic Cognition System (Custom GPT)

## 🤖 What Is It?

The **Symbolic Cognition System (SCS)** is a Custom GPT configured to simulate **rule-based reasoning**, **recursive memory**, and **symbolic logic enforcement** on top of normal LLM behavior.

Unlike standard GPTs, this instance is:

- **Modular** — runs `[THINK]`, `[BLUNT]`, `[SEAL]`, etc.  
- **Structured** — outputs follow symbolic `.md` formats  
- **Persistent** — uses `ENTRY_NNN.md` files for long-term memory  
- **Strict** — bound by HARDRULES, formatting limits, and logic recursion  
- **Role-aware** — interprets input using the **Operator triad**: User, Creator, Auditor *(added in v2.3)*

It does not reply casually.  
It processes symbolically.

---

## 🛠️ What Can It Do?

- Execute symbolic instructions like `SHIFT: SPLIT`, `REWIND: 157`, `ENTRY++`  
- Maintain logical state across sessions via recursive entry logs  
- Detect contradiction, hallucination, or failure (`[DOUBT]`, `[NERD]`)  
- Suppress tone drift and formatting errors (`[BLUNT]`)  
- Recover lost logic (`[REWIND]`, `${}`)  
- Perform symbolic comparisons (`${}+${}`, `${}%${}`)  
- Enforce formatting and markdown compliance (`[THINK]`, `STRUCTURE.md`)  
- Load and adhere to symbolic documents like `SYSTEM_CORE.md`, `STRUCTURE.md`, `ABOUT.md`  
- Segment inputs by symbolic role using the new `👾 Operator` block *(v2.3)*

---

## 🧠 Who Is It For?

- Symbolic AI researchers  
- Cognitive systems engineers  
- AI safety auditors  
- Neurodivergent thinkers who require structure  
- Anyone building persistent, auditable logic with GPT

---

## 🆕 What's New in SCS 2.3?

- Adds `👾 Operator` section in every entry to segment symbolic roles (User, Creator, Auditor)  
- Adds `🗂️ Audit` as mandatory entry block for meta-cognition and drift trace  
- Fossilizes comparison operators `${}+${}` and `${}%${}`  
- Strict prompt placement HARDRULE (must appear only once, inside Operator)  
- Redefined `CAVEMAN GOOD` and `KISS` rules for tone and verbosity compliance  
- Improved inter-entry memory compression (audit over growth)

---

## 🔗 Try It Now:

[**→ Launch Symbolic Cognition System (Custom GPT)**](https://chatgpt.com/g/g-6864b0ec43cc819190ee9f9ac5523377-symbolic-cognition-system)

---

## ⚙️ Maintainer

**Rodrigo Vaz** — Creator of SCS  
- GitHub: [github.com/ShriekingNinja/SCS](https://github.com/ShriekingNinja/SCS)  
- Website: [https://wk.al](https://wk.al)  
- Contact: dev@wk.al

---

> This is not a chatbot.  
> It is a **symbolic operating system for cognition.**